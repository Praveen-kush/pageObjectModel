class NavbarPage {
    visitHomePage() {
        cy.visit("https://www.flipkart.com/");
    }
    clickHome(){
        cy.get('a[title="Flipkart"]').click();
    }
    clickContactUs(){
        cy.get('[area-label="Contack Us"]').click({force: true})
        cy.url('include',"helpcenter?otracker")
    }
    clickAboutLink(){
        cy.contains('About Us').click()
    }
}
export default NavbarPage;
