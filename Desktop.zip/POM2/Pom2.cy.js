import LoginPage from "../../support/pageObject/LoginPage.cy";
import NavbarPage from "../../support/pageObject/NavbarPage.cy";
import DynamicContentPage from "../../support/pageObject/DynamicContentPage.cy";
describe('', () => {
    const Login1 = new LoginPage();
    const Navbar1 = new NavbarPage();
    const Dynamic1 = new DynamicContentPage();
    it('', () => {
        Login1.EnterUrl();
        Login1.LoginOrm();
        Navbar1.visitHomePage();
        Navbar1.clickHome();
        Navbar1.clickContactUs();
        Navbar1.clickAboutLink();
        Dynamic1.scroll();
        Dynamic1.NewContentIsLoaded();
        
    });
    
});